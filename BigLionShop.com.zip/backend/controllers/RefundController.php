<?php
/**
 * 订单退款控制器
 */
namespace backend\controllers;

use yii;
use yii\web\Controller;
use common\models\Refund;
class RefundController extends Controller
{
    public function actionList()
    {
        $refundList = Refund::refundList();
        return $this->render('list', ['refundList' => $refundList]);
    }

    public function actionRefund()
    {
        $batchNum = '201711200000001';
        $num = 1;
        $detail = '2017112021001104700563308219^0.11^不要啦';
        $refundUrl = Yii::$app->alipay->compose('退款','btn btn-success')->refund($batchNum,$num,$detail);
        echo $refundUrl;
        
    }

}